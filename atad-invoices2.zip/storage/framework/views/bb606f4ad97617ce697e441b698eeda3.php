<nav class="navbar navbar-expand-lg bg-primary " data-bs-theme="dark">
  <div class="container">
    <a class="navbar-brand" href="/">
      <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['height' => '30']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['height' => '30']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="<?php echo e(route('pages.dashboard', date('Y'))); ?>">Dashboard</a>
        </li>
        <?php
          $user = auth()->user();
        ?>
        <?php if($user->role == "admin"): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Felhasználók
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo e(route('page.users')); ?>">Minden felhasználó</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('page.user-create')); ?>">Új felhasználó</a></li>
            </ul>
          </li>
        <?php endif; ?>
        <?php if($user->role == "admin" || $user->role == "sales"): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Számlák
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo e(route('pages.all-invoices')); ?>">Minden számla</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('pages.invoices-create')); ?>">Új számla</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('pages.invoices-to-partner')); ?>">Számla partnerhez
                  rendelés</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Partnerek
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo e(route('pages.all-partners')); ?>">Minden partner</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('pages.create-partner')); ?>">Új partner</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('pages.import.partners')); ?>">Partnerek importálása</a></li>
            </ul>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Üzletkötők
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo e(route('pages.all-salesperson')); ?>">Minden üzletkötő</a></li>
              <li><a class="dropdown-item" href="<?php echo e(route('pages.salesperson.partner-connect')); ?>">Üzletkötő partnerhez
                </a></li>
            </ul>
          </li>
          
        <?php endif; ?>
        <?php if($user->role == "salesperson"): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('page.my-partners')); ?>">Saját partnerek</a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" href="<?php echo e(route('page.my-invoices')); ?>">Saját számlák</a>
            </li>
          <?php endif; ?>
      </ul>
      <div>
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <?php echo e($user->name); ?>

            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">Profil</a></li>
              <li>
                <form action="/logout" method="post">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-link">Kijelentkezés</button>
                </form>
              </li>
            </ul>
          </li>
        </ul>


      </div>

    </div>
  </div>
</nav><?php /**PATH F:\projects\php\atad-invoices2\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>