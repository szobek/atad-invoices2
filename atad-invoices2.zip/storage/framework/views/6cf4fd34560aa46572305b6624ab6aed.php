<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if (isset($component)) { $__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.info','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c)): ?>
<?php $attributes = $__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c; ?>
<?php unset($__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c)): ?>
<?php $component = $__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c; ?>
<?php unset($__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c); ?>
<?php endif; ?>
                <h2>Üzletkötő részletei</h2>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($salesperson->name); ?></h5>
                        <p class="card-text"><strong>Email:</strong> <?php echo e($salesperson->email); ?></p>
                        <hr>
                        <h5>Kapcsolódó partnerek:</h5>
                        <?php if($salesperson->partners->isEmpty()): ?>
                            <p>Nincsenek kapcsolódó partnerek.</p>
                        <?php else: ?>
                            <ul>
                                <?php $__currentLoopData = $salesperson->partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($partner->name); ?> - <?php echo e($partner->address); ?></li>
                                    <form action="<?php echo e(route('salesperson.remove-partner')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="partner_id" value="<?php echo e($partner->id); ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">Eltávolítás</button>
                                    </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\projects\php\atad-invoices2\resources\views/pages/salesperson/single.blade.php ENDPATH**/ ?>