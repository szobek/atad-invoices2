<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2><?php echo e($invoice->num); ?></h2>
                    </div>
                    <div class="card-body">

                        <div class="mb-3">
                            <p>Dátum: <?php echo e($invoice->date); ?></p>
                            <p>típus: <?php echo e($invoice->type); ?></p>
                            <p>Fizetési mód: <?php echo e(__("invoice." . $invoice->pay_mode)); ?></p>
                            <p>Összeg: <?php echo e(number_format($invoice->amount, 2, ',', ' ')); ?> Ft</p>

                            <form action="<?php echo e(route('invoice.delete', $invoice->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Biztosan törölni szeretnéd a számlát?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>

                            <a href="<?php echo e(route('pages.all-invoices')); ?>" class="btn btn-secondary mt-4">
                                <i class="fas fa-arrow-left"></i> Vissza a számlákhoz
                            </a>

                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <h3>Partner</h3>
                    <?php if($partner): ?>
                        <p>Név: <?php echo e($partner->name); ?></p>
                        <p>Cím: <?php echo e($partner->address); ?></p>
                        <a href="<?php echo e(route('pages.single-partner', $partner->id)); ?>">Partner adatai</a>
                        <form action="<?php echo e(route('invoice-disconnect-partner')); ?>" method="post" class="mt-2">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="invoice_id" value="<?php echo e($invoice->id); ?>">
                            <button type="submit" class="btn btn-danger"
                                onclick="return confirm('Biztosan le szeretnéd választani a partnert a számláról?')">
                                Partner leválasztása
                            </button>
                    <?php else: ?>
                            <p>Nincs partner hozzárendelve.</p>
                            <form action="<?php echo e(route('invoice-to-partner-save')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="transaction_id" value="<?php echo e($invoice->id); ?>">
                                <label for="partner_id">Válassz partnert:</label>
                                <select name="partner_id" id="partner_id" class="form-control">
                                    <?php $__currentLoopData = App\Models\Partner::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($part->id); ?>"><?php echo e($part->name); ?> - <?php echo e($part->zip); ?><?php echo e($part->address); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-primary mt-2">Partner hozzárendelése</button>
                        <?php endif; ?>

                </div>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\projects\php\atad-invoices2\resources\views/pages/invoice/single-invoice.blade.php ENDPATH**/ ?>