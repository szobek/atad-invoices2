<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <script>
        const chartData=<?php echo json_encode($dashboard_data, 15, 512) ?>;
    </script>

    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <select name="year" id="year">
                    <option value="">Kérlek válassz</option>
                    <option value="2025" <?php if($year == 2025): ?> selected <?php endif; ?>>2025</option>
                    <option value="2026" <?php if($year == 2026): ?> selected <?php endif; ?>>2026</option>
                    <option value="2027" <?php if($year == 2027): ?> selected <?php endif; ?>>2027</option>
                </select>
            </div>
            <div class="col-md-12">
                <p>Kezdő dátum: <?php echo e($dashboard_data["start_date"]); ?></p>
                <p>Végső dátum: <?php echo e($dashboard_data["end_date"]); ?></p>
                <p>Összes számla: <?php echo e($dashboard_data["all_invoice"]); ?></p>
                <p>ebből storno: <?php echo e($dashboard_data["all_storno"]); ?></p>

            </div>
        </div>
        <div class="row chart-container" id="chart-container"></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\projects\php\atad-invoices2\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>