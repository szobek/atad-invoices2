<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <form method="GET" action="<?php echo e(route('pages.all-invoices')); ?>" class="mb-4">
                    <div>
                        <p>
                            Keresés számlaszám alapján:
                        </p>
                    </div>
                    <div class="d-flex gap-2">
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                            placeholder="Keresés számlaszám alapján..." class="form-control">
                        <button type="submit" class="btn btn-secondary">
                            Keresés
                        </button>
                    </div>
                </form>
            </div>
            <div class="col-12">

                <table class="table stripped">
                    <thead>
                        <tr>
                            <th>Számlaszám</th>
                            <th>Dátum</th>
                            <th>Típus</th>
                            <th>Fizetési mód</th>
                            <th>Összeg</th>
                            <th>Megjegyzés</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr class="<?php if($invoice->type == "storno"): ?> bg-red <?php endif; ?>">
                                <td>
                                    <a href="<?php echo e(route('pages.single-invoice', $invoice->id)); ?>">
                                        <?php echo e($invoice->num); ?>

                                    </a>
                                </td>
                                <td><?php echo e($invoice->date); ?></td>
                                <td><?php echo e($invoice->type); ?></td>
                                <td><?php echo e(__("invoice." . $invoice->pay_mode)); ?></td>
                                <td><?php echo e(number_format($invoice->amount, 2, ',', ' ')); ?> Ft</td>
                                <td><?php echo e($invoice->comment); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($invoices->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\projects\php\atad-invoices2\resources\views/pages/invoice/all-invoices.blade.php ENDPATH**/ ?>