<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Számla partnerhez rendelése'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php if (isset($component)) { $__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.info','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c)): ?>
<?php $attributes = $__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c; ?>
<?php unset($__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c)): ?>
<?php $component = $__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c; ?>
<?php unset($__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c); ?>
<?php endif; ?>
    <div class="container mt-4">
        <form action="<?php echo e(route('invoice-to-partner-save')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">

                <div class="col-md-4">
                    <select name="partner_id" id="partner_id" class="form-select">
                        <option value="">Kérlek válassz</option>
                        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($partner->id); ?>">
                            <?php echo e($partner->name); ?>

                                <?php echo e($partner->zip); ?> <?php echo e($partner->city); ?> <?php echo e($partner->address); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="col-md-4">
                    <select name="invoice_id" id="invoice_id" class="form-select">
                        <option value="">Kérlek válassz</option>
                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($invoice->id); ?>"><?php echo e($invoice->num); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    
                </div>
                
                <div class="col-md-4">
                    <button class="btn btn-primary">Mentés</button>
                    
                </div>


        </form>
    </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\projects\php\atad-invoices2\resources\views/pages/invoice/connect-to-partner.blade.php ENDPATH**/ ?>