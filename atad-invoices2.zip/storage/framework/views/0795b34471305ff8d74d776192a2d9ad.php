<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if (isset($component)) { $__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.info','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c)): ?>
<?php $attributes = $__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c; ?>
<?php unset($__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c)): ?>
<?php $component = $__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c; ?>
<?php unset($__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c); ?>
<?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h3>Partner adatok</h3>
                    </div>
                    <div class="card-body">
                        <p>Név: <?php echo e($partner->name); ?></p>
                        <p>Cím: <?php echo e($partner->zip); ?> <?php echo e($partner->city); ?>, <?php echo e($partner->address); ?> </p>
                        <p>Adószám: <?php echo e($partner->tax); ?></p>
                        <div class="d-flex gap-3">
                            <form action="<?php echo e(route('partner.delete', $partner->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Biztosan törölni szeretnéd a partnert?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            <form action="<?php echo e(route('partner.edit', $partner->id)); ?>" method="get">
                                <button type="submit" class="btn btn-success"
                                    onclick="return confirm('Biztosan módosítani szeretnéd a partnert?')">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </form>
                        </div>

                        <hr>
                        <p>Partner számlái</p>
                        <table>

                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('pages.single-invoice', $invoice->id)); ?>"><?php echo e($invoice->num); ?></a>
                                    </td>
                                    <td style="padding-left: 20px;">Dátum: <?php echo e($invoice->date); ?></td>
                                    <td style="padding-left: 20px;">Összeg: <?php echo e(number_format($invoice->amount, 2)); ?>

                                        <?php echo e($invoice->currency); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>

            </div>
        </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\projects\php\atad-invoices2\resources\views/pages/partner/single-partner.blade.php ENDPATH**/ ?>