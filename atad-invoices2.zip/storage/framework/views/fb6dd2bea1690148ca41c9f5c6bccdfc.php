<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            </div>
            <?php if (isset($component)) { $__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.info','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c)): ?>
<?php $attributes = $__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c; ?>
<?php unset($__attributesOriginalcc3646f272fffe9fa9c1a8c2c788b35c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c)): ?>
<?php $component = $__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c; ?>
<?php unset($__componentOriginalcc3646f272fffe9fa9c1a8c2c788b35c); ?>
<?php endif; ?>
            <h2>Összes partner</h2>
            <div class="col-md-12 d-flex gap-4 flex-wrap">

                <form method="GET" action="<?php echo e(route('pages.all-partners')); ?>" class="mb-4">
                    <div>
                        <p>
                            Keresés név alapján:
                        </p>
                    </div>
                    <div class="d-flex gap-2">
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                            placeholder="Keresés név alapján..." class="form-control">

                        <button type="submit" class="btn btn-secondary">
                            Keresés
                        </button>
                    </div>
                </form>


                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Név</th>
                            <th>Cím</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('pages.single-partner', [$partner->id])); ?>">
                                        <?php echo e($partner->name); ?>

                                    </a>
                                </td>
                                <td><?php echo e($partner->zip); ?> <?php echo e($partner->city); ?> <?php echo e($partner->address); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($partners->links()); ?>


            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\projects\php\atad-invoices2\resources\views/pages/partner/all.blade.php ENDPATH**/ ?>