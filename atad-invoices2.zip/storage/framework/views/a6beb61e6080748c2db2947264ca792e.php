<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon"/>
    <!-- Fonts -->
    <title><?php echo e($title ? $title . ' | ' : ''); ?> <?php echo e(config('app.name', 'Atád Clean kft.')); ?></title>
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>

<body >
    <div>
        <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php if(isset($header)): ?>
            <header class="">
                <div >
                    <?php echo e($header); ?>

                </div>
            </header>
        <?php endif; ?>

        <!-- Page Content -->
        <main>
            <?php echo e($slot); ?>

            <div class="upper"></div>
        </main>
    </div>
</body>

</html><?php /**PATH F:\projects\php\atad-invoices2\resources\views/layouts/app.blade.php ENDPATH**/ ?>